const canvas = document.querySelector(".pytonuch")
const canvasContext = canvas.getContext("2d")

const minSize = 32


const ground= new Image()
ground.src = "img/ground.png"

const foodImg = new Image()
foodImg.src = "img/food.png"

let snake = []

snake[0] = {
    x : Math.floor(Math.random()*17+1) * minSize,
    y : Math.floor(Math.random()*15+3) * minSize
}

let food= {
    x : Math.floor(Math.random()*17+1) * minSize,
    y : Math.floor(Math.random()*15+3) * minSize
}

let score = 0

let directory

document.addEventListener("keydown",direction)

function direction({keyCode}){
    directory= (keyCode == 37 && directory!= "RIGHT")? "LEFT":
        (keyCode == 38 && directory!= "DOWN")? "UP":
        (keyCode == 39 && directory!= "LEFT")? "RIGHT":
        (keyCode == 40 && directory!= "UP")? "DOWN" : directory
}

function collision(head,array){
    for(let i in array)
        if(head.x == array[i].x && head.y == array[i].y)
            return true
    return false
}

function draw(){
    
    canvasContext.drawImage(ground,0,0)
    
    for( let i = 0; i < snake.length;  i++){
        canvasContext.fillStyle = "orange"
        canvasContext.fillRect(snake[i].x,snake[i].y,minSize,minSize)
        canvasContext.strokeStyle = "black"
        canvasContext.strokeRect(snake[i].x,snake[i].y,minSize,minSize)
    }
    
    canvasContext.drawImage(foodImg, food.x, food.y)
    
    let snakeX = snake[0].x
    let snakeY = snake[0].y
    
    if( directory== "LEFT") snakeX -= minSize
    if( directory== "UP") snakeY -= minSize
    if( directory== "RIGHT") snakeX += minSize
    if( directory== "DOWN") snakeY += minSize
    
    if(snakeX == food.x && snakeY == food.y){
        score++
        food= {
            x : Math.floor(Math.random()*17+1) * minSize,
            y : Math.floor(Math.random()*15+3) * minSize
        }
    }else{
        snake.pop()
    }
    
    
    let newHead= {
        x : snakeX,
        y : snakeY
    }
    
    
    if(snakeX < minSize || snakeX > 17 * minSize || snakeY < 3*minSize || snakeY > 17*minSize || collision(newHead,snake)){
        clearInterval(game)
        document.querySelector('body').innerHTML = 
        `<div class="game-over">
            <p>GameOver</p>
            <p>Twój wynik to: ${score}</p>
            <p>Smakowały cegły?</p>
        </div>`
    }
    
    snake.unshift(newHead)
    
    canvasContext.fillStyle = "white"
    canvasContext.font = "45px Changa one"
    canvasContext.fillText(score,2*minSize,1.6*minSize)
}


















